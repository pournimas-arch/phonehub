import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:phonehub/customer/data.dart';
import 'package:phonehub/customer/product_list_screen.dart';
import 'package:phonehub/customer/shared_ui.dart';
import 'package:phonehub/customer/theme.dart';


// ---------- Shared styling (same as Home screen) ----------

BoxDecoration _glass({double radius = 18}) => BoxDecoration(
  color: Colors.white,
  borderRadius: BorderRadius.circular(radius),
  border: Border.all(color: const Color(0xFFDCE8FF)),
  boxShadow: [BoxShadow(color: const Color(0xFF3D5BB8).withValues(alpha: 0.10), blurRadius: 20, spreadRadius: 0.5, offset: const Offset(0, 8))],
);

const _bgGradient = LinearGradient(
  begin: Alignment.topCenter,
  end: Alignment.bottomCenter,
  colors: [Color(0xFFF4F8FF), Color(0xFFBBD5FB), Color(0xFF7FADEE)],
);

class _Blob extends StatelessWidget {
  final double size;
  final double alpha;
  const _Blob(this.size, this.alpha);

  @override
  Widget build(BuildContext context) => Container(
    width: size,
    height: size,
    decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withValues(alpha: alpha)),
  );
}

class CategoriesScreen extends StatelessWidget {
  const CategoriesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final totalPhones = phones.length;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Scaffold(
        backgroundColor: Colors.white,
        body: Container(
          decoration: const BoxDecoration(gradient: _bgGradient),
          child: Stack(
            children: [
              Positioned(top: -70, right: -80, child: _Blob(240, 0.35)),
              Positioned(top: 420, left: -120, child: _Blob(280, 0.20)),
              SafeArea(
                bottom: false,
                child: CustomScrollView(
                  slivers: [
                    // ---- Header ----
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
                      sliver: SliverToBoxAdapter(child: _header(context)),
                    ),

                    // ---- Summary banner ----
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(20, 22, 20, 0),
                      sliver: SliverToBoxAdapter(child: _banner(context, totalPhones)),
                    ),

                    // ---- Section title ----
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(20, 26, 20, 16),
                      sliver: SliverToBoxAdapter(child: _sectionTitle('Shop by Brand', 'See all', () => _open(context))),
                    ),

                    // ---- Brand grid ----
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 28),
                      sliver: SliverGrid(
                        delegate: SliverChildBuilderDelegate(
                              (context, i) => _brandCard(context, brands[i]),
                          childCount: brands.length,
                        ),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          mainAxisSpacing: 16,
                          crossAxisSpacing: 16,
                          childAspectRatio: 0.98,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _open(BuildContext context, [String? brand]) => Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => brand == null ? const ProductListScreen() : ProductListScreen(brand: brand)),
  );

  // ---- Header: title + search button ----
  Widget _header(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            color: AppColors.primary,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.white, width: 2),
            boxShadow: [BoxShadow(color: AppColors.primary.withValues(alpha: 0.30), blurRadius: 12, offset: const Offset(0, 5))],
          ),
          child: const Icon(Icons.grid_view_rounded, color: Colors.white, size: 22),
        ),
        const SizedBox(width: 12),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Browse by', style: TextStyle(color: AppColors.muted, fontSize: 11.5)),
              SizedBox(height: 3),
              Text('Categories', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: AppColors.text, letterSpacing: -0.45)),
            ],
          ),
        ),
        Container(
          decoration: _glass(radius: 14),
          child: IconButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProductListScreen(autofocus: true))),
            icon: const Icon(Icons.search_rounded, color: AppColors.text, size: 22),
          ),
        ),
      ],
    );
  }

  // ---- Gradient summary banner ----
  Widget _banner(BuildContext context, int totalPhones) {
    return Container(
      height: 132,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: brandGradient,
        boxShadow: [BoxShadow(color: AppColors.primary.withValues(alpha: 0.30), blurRadius: 24, offset: const Offset(0, 12))],
      ),
      child: Stack(
        children: [
          Positioned(right: -30, top: -30, child: CircleAvatar(radius: 80, backgroundColor: Colors.white.withValues(alpha: 0.08))),
          Positioned(left: -40, bottom: -50, child: CircleAvatar(radius: 60, backgroundColor: Colors.white.withValues(alpha: 0.05))),
          Positioned(right: 16, bottom: 8, child: Icon(Icons.phone_android_rounded, size: 84, color: Colors.white.withValues(alpha: 0.22))),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(color: AppColors.accent, borderRadius: BorderRadius.circular(10)),
                  child: const Text('ALL BRANDS', style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 0.8)),
                ),
                const SizedBox(height: 9),
                Text('${brands.length} brands · $totalPhones phones', style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900, letterSpacing: -0.45)),
                const SizedBox(height: 2),
                const Text('pick a brand to explore', style: TextStyle(color: Colors.white70, fontSize: 11.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ---- Section title (same as Home) ----
  Widget _sectionTitle(String title, String action, VoidCallback onTap) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 22,
          decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(4)),
        ),
        const SizedBox(width: 8),
        Expanded(child: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.text, fontSize: 17, fontWeight: FontWeight.w800, letterSpacing: -0.3))),
        GestureDetector(
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
            decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.75), borderRadius: BorderRadius.circular(20)),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(action, style: const TextStyle(color: AppColors.primary, fontSize: 10.5, fontWeight: FontWeight.w800)),
                const SizedBox(width: 2),
                const Icon(Icons.arrow_forward_ios_rounded, size: 10, color: AppColors.primary),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ---- Brand card ----
  Widget _brandCard(BuildContext context, String b) {
    final c = brandColors[b] ?? AppColors.primary;
    final count = phones.where((p) => p.brand == b).length;

    return Tap(
      onTap: () => _open(context, b),
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: const Color(0xFFDCE8FF), width: 1.1),
          boxShadow: [BoxShadow(color: c.withValues(alpha: 0.16), blurRadius: 20, offset: const Offset(0, 9))],
        ),
        child: Stack(
          children: [
            Positioned(right: -24, top: -24, child: CircleAvatar(radius: 52, backgroundColor: c.withValues(alpha: 0.08))),
            Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      border: Border.all(color: c.withValues(alpha: 0.35), width: 1.5),
                      boxShadow: [BoxShadow(color: c.withValues(alpha: 0.20), blurRadius: 14, offset: const Offset(0, 6))],
                    ),
                    alignment: Alignment.center,
                    child: Text(b[0], style: TextStyle(color: c, fontWeight: FontWeight.w900, fontSize: 20)),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(b, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14.5, color: AppColors.text)),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Expanded(child: Text('$count phones', style: const TextStyle(color: AppColors.muted, fontSize: 11.5))),
                          Container(
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(color: c.withValues(alpha: 0.12), shape: BoxShape.circle),
                            child: Icon(Icons.arrow_outward_rounded, size: 14, color: c),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
