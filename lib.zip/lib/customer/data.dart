import 'package:flutter/material.dart';

class Phone {
  final String id, name, brand, storage, condition;
  final int price, mrp, battery;
  final double rating;
  final List<Color> colors;

  const Phone({
    required this.id,
    required this.name,
    required this.brand,
    required this.storage,
    required this.condition,
    required this.price,
    required this.mrp,
    required this.battery,
    required this.rating,
    required this.colors,
  });

  int get off => (((mrp - price) / mrp) * 100).round();
}

const brands = ['Apple', 'Samsung', 'OnePlus', 'Xiaomi', 'Realme'];

const brandColors = {
  'Apple': Color(0xFF1B1B2F),
  'Samsung': Color(0xFF1D4ED8),
  'OnePlus': Color(0xFFDC2626),
  'Xiaomi': Color(0xFFEA580C),
  'Realme': Color(0xFFCA8A04),
};

final List<Phone> phones = [
  const Phone(id: 'p1', name: 'iPhone 13', brand: 'Apple', storage: '128 GB', condition: 'Like New', price: 42999, mrp: 59900, battery: 92, rating: 4.7, colors: [Color(0xFF1E3A8A), Color(0xFF3B82F6)]),
  const Phone(id: 'p2', name: 'iPhone 12', brand: 'Apple', storage: '64 GB', condition: 'Good', price: 29999, mrp: 45900, battery: 88, rating: 4.5, colors: [Color(0xFF111827), Color(0xFF6B7280)]),
  const Phone(id: 'p3', name: 'Galaxy S21', brand: 'Samsung', storage: '128 GB', condition: 'Good', price: 27999, mrp: 69999, battery: 90, rating: 4.4, colors: [Color(0xFF2E4A9A), Color(0xFFC084FC)]),
  const Phone(id: 'p4', name: 'Galaxy A54', brand: 'Samsung', storage: '128 GB', condition: 'Like New', price: 22499, mrp: 38999, battery: 95, rating: 4.3, colors: [Color(0xFF0F766E), Color(0xFF2DD4BF)]),
  const Phone(id: 'p5', name: 'OnePlus 11R', brand: 'OnePlus', storage: '256 GB', condition: 'Like New', price: 31999, mrp: 44999, battery: 94, rating: 4.6, colors: [Color(0xFFB91C1C), Color(0xFFF87171)]),
  const Phone(id: 'p6', name: 'OnePlus Nord CE 3', brand: 'OnePlus', storage: '128 GB', condition: 'Good', price: 14999, mrp: 26999, battery: 89, rating: 4.2, colors: [Color(0xFF065F46), Color(0xFF34D399)]),
  const Phone(id: 'p7', name: 'Redmi Note 12 Pro', brand: 'Xiaomi', storage: '128 GB', condition: 'Fair', price: 12499, mrp: 27999, battery: 85, rating: 4.1, colors: [Color(0xFFC2410C), Color(0xFFFB923C)]),
  const Phone(id: 'p8', name: 'Xiaomi 11T Pro', brand: 'Xiaomi', storage: '256 GB', condition: 'Good', price: 24999, mrp: 49999, battery: 90, rating: 4.4, colors: [Color(0xFF0369A1), Color(0xFF38BDF8)]),
  const Phone(id: 'p9', name: 'Realme GT Neo 3', brand: 'Realme', storage: '256 GB', condition: 'Good', price: 19999, mrp: 36999, battery: 91, rating: 4.3, colors: [Color(0xFFA16207), Color(0xFFFACC15)]),
  const Phone(id: 'p10', name: 'Realme 11 Pro', brand: 'Realme', storage: '128 GB', condition: 'Like New', price: 17999, mrp: 27999, battery: 96, rating: 4.2, colors: [Color(0xFFBE185D), Color(0xFFF472B6)]),
];

// ---------------- Cart & Wishlist state (simple, no packages) ----------------

class CartItem {
  final Phone phone;
  final String storage;
  final String condition;
  int qty;
  CartItem(this.phone, this.storage, this.condition, {this.qty = 1});
}

final ValueNotifier<List<CartItem>> cart = ValueNotifier<List<CartItem>>([]);
final ValueNotifier<Set<String>> wishlist = ValueNotifier<Set<String>>({});

void addToCart(Phone p, String storage, String condition) {
  final list = List<CartItem>.from(cart.value);
  final i = list.indexWhere((e) => e.phone.id == p.id && e.storage == storage && e.condition == condition);
  if (i >= 0) {
    list[i].qty = (list[i].qty + 1).clamp(1, 5);
  } else {
    list.add(CartItem(p, storage, condition));
  }
  cart.value = list;
}

void changeQty(CartItem item, int delta) {
  item.qty = (item.qty + delta).clamp(1, 5);
  cart.value = List<CartItem>.from(cart.value);
}

void removeItem(CartItem item) {
  cart.value = cart.value.where((e) => e != item).toList();
}

void toggleWish(String id) {
  final s = Set<String>.from(wishlist.value);
  if (!s.add(id)) s.remove(id);
  wishlist.value = s;
}

String rupee(int v) {
  final s = v.toString();
  if (s.length <= 3) return '₹$s';
  final last3 = s.substring(s.length - 3);
  var rest = s.substring(0, s.length - 3);
  final parts = <String>[];
  while (rest.length > 2) {
    parts.insert(0, rest.substring(rest.length - 2));
    rest = rest.substring(0, rest.length - 2);
  }
  if (rest.isNotEmpty) parts.insert(0, rest);
  return '₹${parts.join(',')},$last3';
}

// ---------------- User profile & accounts (in-memory, no backend) ----------------

class UserProfile {
  final String name, phone, email;
  const UserProfile({required this.name, required this.phone, required this.email});

  String get firstName => name.trim().isEmpty ? 'there' : name.trim().split(' ').first;
  String get initial => name.trim().isEmpty ? 'P' : name.trim()[0].toUpperCase();
}

class Account {
  final String password;
  final UserProfile profile;
  const Account(this.password, this.profile);
}

/// Everyone who can sign in (email in lower case -> account). Register adds to this map.
final Map<String, Account> accounts = {
  'pournima@gmail.com': const Account(
    'test@123',
    UserProfile(name: 'Pournima Salunkhe', phone: '+91 98765 43210', email: 'pournima@gmail.com'),
  ),
};

/// The signed-in customer. Home header, Profile tab and Edit Profile all read this.
final ValueNotifier<UserProfile> profile = ValueNotifier<UserProfile>(accounts['pournima@gmail.com']!.profile);

void updateProfile(UserProfile p) {
  final old = profile.value;
  final acc = accounts.remove(old.email.toLowerCase());
  accounts[p.email.toLowerCase()] = Account(acc?.password ?? '', p);
  profile.value = p;
}

// ---------------- Coupons ----------------

class Coupon {
  final String code, title, note;
  final int flat, percent, maxOff, minOrder;
  final bool freeDelivery, firstOrderOnly;
  const Coupon({
    required this.code,
    required this.title,
    required this.note,
    this.flat = 0,
    this.percent = 0,
    this.maxOff = 0,
    this.minOrder = 0,
    this.freeDelivery = false,
    this.firstOrderOnly = false,
  });
}

const List<Coupon> coupons = [
  Coupon(code: 'PHONEHUB500', title: 'Flat ₹500 off on your order', note: 'On orders of ₹5,000 or more', flat: 500, minOrder: 5000),
  Coupon(code: 'FREEDELIVERY', title: 'Free delivery on any order', note: 'Saves the ₹99 delivery charge', freeDelivery: true),
  Coupon(code: 'NEWUSER10', title: '10% off on your first order', note: 'Up to ₹2,000 off, first order only', percent: 10, maxOff: 2000, firstOrderOnly: true),
];

Coupon? findCoupon(String code) {
  final c = code.trim().toUpperCase();
  for (final x in coupons) {
    if (x.code == c) return x;
  }
  return null;
}

/// Returns a message when the coupon cannot be used on this cart, or null when it is valid.
String? couponError(Coupon c, int subtotal, int delivery) {
  if (subtotal < c.minOrder) return '${c.code} needs a minimum order of ${rupee(c.minOrder)}';
  if (c.firstOrderOnly && orders.value.any((o) => !o.isDemo)) return '${c.code} is valid on your first order only';
  if (c.freeDelivery && delivery == 0) return 'Delivery is already free on this order';
  return null;
}

int couponDiscount(Coupon c, int subtotal, int delivery) {
  var d = c.flat;
  if (c.percent > 0) {
    d += subtotal * c.percent ~/ 100;
    if (c.maxOff > 0 && d > c.maxOff) d = c.maxOff;
  }
  if (c.freeDelivery) d += delivery;
  final cap = subtotal + delivery;
  return d > cap ? cap : d;
}

// ---------------- Orders ----------------

const List<String> orderSteps = ['Order Placed', 'Payment Confirmed', 'Packed', 'Out for Delivery', 'Delivered'];

class Order {
  final String id, paymentMethod, addressLabel, addressLine;
  final List<CartItem> items;
  final int subtotal, delivery, discount, total;
  final String? couponCode;
  final DateTime placedAt;

  /// Demo orders (the two sample orders every account starts with) never move on their own.
  final bool isDemo;
  final int? fixedStage;
  bool cancelled;

  Order({
    required this.id,
    required this.items,
    required this.subtotal,
    required this.delivery,
    required this.discount,
    required this.total,
    required this.paymentMethod,
    required this.addressLabel,
    required this.addressLine,
    required this.placedAt,
    this.couponCode,
    this.isDemo = false,
    this.fixedStage,
    this.cancelled = false,
  });

  /// 0 Placed, 1 Payment Confirmed, 2 Packed, 3 Out for Delivery, 4 Delivered.
  /// A new order starts at "Packed" and moves forward by itself (every 45 s) so the whole
  /// flow can be demonstrated without a backend. Replace this getter with the status from your server.
  int get stage {
    if (fixedStage != null) return fixedStage!;
    final s = DateTime.now().difference(placedAt).inSeconds;
    return (2 + s ~/ 45).clamp(2, 4);
  }

  bool get isDelivered => !cancelled && stage >= 4;
  bool get isOngoing => !cancelled && stage < 4;
  String get statusLabel => cancelled ? 'Cancelled' : orderSteps[stage];
  int get itemCount => items.fold<int>(0, (s, e) => s + e.qty);
  String get title => items.length == 1 ? items.first.phone.name : '${items.first.phone.name} +${items.length - 1} more';

  DateTime stepTime(int k) {
    if (isDemo) return placedAt.add(Duration(minutes: const [0, 1, 85, 190, 400][k]));
    return placedAt.add(Duration(seconds: const [0, 5, 10, 45, 90][k]));
  }

  String get etaText => isDemo ? 'Arriving today by 6:00 PM' : 'Arriving in a few minutes';
}

int _orderSeq = 4821;

final ValueNotifier<List<Order>> orders = ValueNotifier<List<Order>>([
  Order(
    id: '#PH-20261009-4821',
    items: [CartItem(phones[0], '128 GB', 'Like New')],
    subtotal: 42999,
    delivery: 0,
    discount: 0,
    total: 42999,
    paymentMethod: 'UPI (GPay)',
    addressLabel: 'Home',
    addressLine: 'Flat 302, Shivaji Nagar, Pune, Maharashtra - 411005',
    placedAt: DateTime(2026, 10, 9, 13, 5),
    isDemo: true,
    fixedStage: 3,
  ),
  Order(
    id: '#PH-20260928-3307',
    items: [CartItem(phones[2], '128 GB', 'Good')],
    subtotal: 27999,
    delivery: 0,
    discount: 0,
    total: 27999,
    paymentMethod: 'Debit / Credit Card',
    addressLabel: 'Home',
    addressLine: 'Flat 302, Shivaji Nagar, Pune, Maharashtra - 411005',
    placedAt: DateTime(2026, 9, 28, 11, 20),
    isDemo: true,
    fixedStage: 4,
  ),
]);

Order placeOrder({
  required List<CartItem> items,
  required int subtotal,
  required int delivery,
  required int discount,
  required int total,
  required String paymentMethod,
  required String addressLabel,
  required String addressLine,
  String? couponCode,
}) {
  _orderSeq++;
  final now = DateTime.now();
  final stamp = '${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}';
  final o = Order(
    id: '#PH-$stamp-$_orderSeq',
    items: items.map((e) => CartItem(e.phone, e.storage, e.condition, qty: e.qty)).toList(),
    subtotal: subtotal,
    delivery: delivery,
    discount: discount,
    total: total,
    couponCode: couponCode,
    paymentMethod: paymentMethod,
    addressLabel: addressLabel,
    addressLine: addressLine,
    placedAt: now,
  );
  orders.value = [o, ...orders.value];
  return o;
}

void cancelOrder(Order o) {
  o.cancelled = true;
  orders.value = List<Order>.from(orders.value);
}

void reorder(Order o) {
  for (final it in o.items) {
    for (int i = 0; i < it.qty; i++) {
      addToCart(it.phone, it.storage, it.condition);
    }
  }
}

String fmtDateTime(DateTime d) {
  const m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  final h = d.hour % 12 == 0 ? 12 : d.hour % 12;
  final mm = d.minute.toString().padLeft(2, '0');
  return '${d.day.toString().padLeft(2, '0')} ${m[d.month - 1]}, $h:$mm ${d.hour >= 12 ? 'PM' : 'AM'}';
}