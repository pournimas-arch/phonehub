import 'package:flutter/material.dart';
import 'theme.dart';
import 'data.dart';

/// Edit Profile – name, phone and email. Saving updates the whole app
/// (home greeting, profile card) and the sign-in account.
class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  late final _name = TextEditingController(text: profile.value.name);
  late final _phone = TextEditingController(text: profile.value.phone);
  late final _email = TextEditingController(text: profile.value.email);

  @override
  void initState() {
    super.initState();
    // Keeps the avatar letter in sync while typing.
    _name.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _email.dispose();
    super.dispose();
  }

  void _save() {
    FocusScope.of(context).unfocus();
    if (!_formKey.currentState!.validate()) return;
    final newEmail = _email.text.trim().toLowerCase();
    final oldEmail = profile.value.email.toLowerCase();
    if (newEmail != oldEmail && accounts.containsKey(newEmail)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('This email is already used by another account')));
      return;
    }
    updateProfile(UserProfile(name: _name.text.trim(), phone: _phone.text.trim(), email: _email.text.trim()));
    final messenger = ScaffoldMessenger.of(context);
    Navigator.pop(context);
    messenger.showSnackBar(const SnackBar(content: Text('Profile updated')));
  }

  Widget _field(String label, TextEditingController c, IconData icon, String? Function(String?) validator, {TextInputType? type}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: AppColors.text)),
          const SizedBox(height: 6),
          Container(
            decoration: cardDeco(radius: 16),
            child: TextFormField(
              controller: c,
              keyboardType: type,
              validator: validator,
              decoration: InputDecoration(
                prefixIcon: Icon(icon, color: AppColors.muted, size: 20),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(vertical: 16),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Edit Profile')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
          children: [
            Center(
              child: CircleAvatar(
                radius: 38,
                backgroundColor: AppColors.primary,
                child: Text(
                  _name.text.trim().isEmpty ? 'P' : _name.text.trim()[0].toUpperCase(),
                  style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w800),
                ),
              ),
            ),
            const SizedBox(height: 22),
            _field('Full name', _name, Icons.person_outline_rounded, (v) => (v == null || v.trim().length < 2) ? 'Enter your name' : null),
            _field('Phone number', _phone, Icons.phone_outlined, (v) => (v == null || v.replaceAll(RegExp(r'\D'), '').length < 10) ? 'Enter a valid phone number' : null, type: TextInputType.phone),
            _field('Email', _email, Icons.email_outlined, (v) => (v == null || !RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(v.trim())) ? 'Enter a valid email' : null, type: TextInputType.emailAddress),
            const SizedBox(height: 8),
            ElevatedButton(onPressed: _save, child: const Text('Save Changes')),
          ],
        ),
      ),
    );
  }
}