import 'package:flutter/material.dart';
import 'widgets.dart';
import 'theme.dart';
import 'data.dart';

/// Wishlist – shows every phone the customer has tapped the heart on.
class WishlistScreen extends StatelessWidget {
  const WishlistScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Wishlist')),
      body: ValueListenableBuilder<Set<String>>(
        valueListenable: wishlist,
        builder: (context, ids, _) {
          final saved = phones.where((p) => ids.contains(p.id)).toList();

          if (saved.isEmpty) {
            return const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.favorite_border_rounded, size: 80, color: AppColors.muted),
                  SizedBox(height: 10),
                  Text('Your wishlist is empty', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                  SizedBox(height: 4),
                  Text('Tap the heart on any phone to save it here', style: TextStyle(color: AppColors.muted)),
                ],
              ),
            );
          }

          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 8),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text('${saved.length} saved ${saved.length == 1 ? 'phone' : 'phones'}', style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600)),
                ),
              ),
              Expanded(
                child: GridView.builder(
                  padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
                  itemCount: saved.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 14, crossAxisSpacing: 14, mainAxisExtent: 252),
                  itemBuilder: (_, i) => PhoneCard(phone: saved[i]),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
