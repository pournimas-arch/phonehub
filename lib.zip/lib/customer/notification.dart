import 'package:flutter/material.dart';
import 'theme.dart';

class _Notif {
  final IconData icon;
  final Color color;
  final String title, body, time;
  bool unread;
  _Notif(this.icon, this.color, this.title, this.body, this.time, {this.unread = false});
}

/// Notifications – order updates, offers and price drops.
class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  final List<_Notif> items = [
    _Notif(Icons.local_shipping_rounded, AppColors.primary, 'Order on the way', 'Your phone is out for delivery and will arrive today.', '10 min ago', unread: true),
    _Notif(Icons.local_offer_rounded, AppColors.accent, 'New offer for you', 'Use code PHONEHUB500 to save ₹500 on your next order.', '2 hrs ago', unread: true),
    _Notif(Icons.trending_down_rounded, AppColors.success, 'Price drop', 'A phone on your wishlist just got cheaper.', 'Yesterday'),
    _Notif(Icons.verified_rounded, AppColors.primary, 'Order confirmed', 'Thanks for shopping with PhoneHub. Your order is confirmed.', '2 days ago'),
  ];

  bool get hasUnread => items.any((n) => n.unread);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        actions: [
          if (hasUnread)
            TextButton(
              onPressed: () => setState(() {
                for (final n in items) {
                  n.unread = false;
                }
              }),
              child: const Text('Mark all read', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
            ),
        ],
      ),
      body: items.isEmpty
          ? const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.notifications_none_rounded, size: 80, color: AppColors.muted),
            SizedBox(height: 10),
            Text('No notifications yet', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
          ],
        ),
      )
          : ListView.separated(
        padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (_, i) {
          final n = items[i];
          return GestureDetector(
            onTap: () => setState(() => n.unread = false),
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: cardDeco(),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: n.color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(12)),
                    child: Icon(n.icon, color: n.color, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(child: Text(n.title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14, color: AppColors.text))),
                            if (n.unread) Container(width: 8, height: 8, decoration: const BoxDecoration(color: AppColors.accent, shape: BoxShape.circle)),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(n.body, style: const TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.35)),
                        const SizedBox(height: 6),
                        Text(n.time, style: const TextStyle(color: AppColors.muted, fontSize: 11, fontWeight: FontWeight.w600)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
